package com.example.final_dino1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
